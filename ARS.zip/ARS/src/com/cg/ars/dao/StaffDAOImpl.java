package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class StaffDAOImpl implements IStaffDAO {

	@Override
	public boolean verifyUser(String userName, String password, String role)
			throws ARSException {
		
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperStaff.VERIFY_USER);) {
			String user=null;
			long mobileNumber=0;
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);
			preparedStatement.setString(3, role);
			
			
			ResultSet resultset=preparedStatement.executeQuery();
			while (resultset.next()) {
				
			 user = resultset.getString(1);
			 mobileNumber=resultset.getLong(2);
				
			}
			} catch (Exception e) {
				throw new ARSException(e.getMessage());
			}

			return false;
	}

	@Override
	public List<FlightInformationBean> viewFlightInformation()
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperStaff.VIEW_FLIGHT_INFORMATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
	}

	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperStaff.VIEW_PARTICULAR_FLIGHT_INFORMATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
	}

	@Override
	public boolean updateFlightInformation(FlightInformationBean flightInfoBean)
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperStaff.UPDATE_FLIGHT_INFORMATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return false;
	}

	@Override
	public List<FlightInformationBean> viewOverAllOccupancy(String sourceCity,
			String destinationCity) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperStaff.VIEW_OVER_ALL_OCCUPANCY);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
	}

	@Override
	public int viewPeriodOccupancy(String flightNumber, LocalDate fromDate,
			LocalDate toDate) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperStaff.VIEW_PERIOD_OCCUPANCY);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return 0;
	}

	

		
	//Don't implement this method implement above method
	
	
/* WRONG METHOD IMPLEMENTED
	@Override
	public String verifyUser(String userName,String password,String role) throws ARSException {

		String user = null;
		try(Connection connPurchaseDetails =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapper.VALID_USER);
				){
				preparedStatement.setString(1, userName);
				preparedStatement.setString(2, password);
				preparedStatement.setString(3, role);
				
				
				ResultSet resultset=preparedStatement.executeQuery();
				while (resultset.next()) {
					
				user=resultset.getString(1);
					
				}
			
		}catch(SQLException sqlEx){
			throw new ARSException(sqlEx.getMessage());
		}
		
		return user;
	}*/
}


