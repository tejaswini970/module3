package com.cg.ars.dao;

public interface IQueryMapperStaff {
	
	public static final String VERIFY_USER = "SELECT username, mobile_no FROM users WHERE (username=? and password=? and role=?)";
	
	public static final String VIEW_FLIGHT_INFORMATION ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation";
	
	public static final String VIEW_PARTICULAR_FLIGHT_INFORMATION ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation WHERE flightno=?";
	
	public static final String UPDATE_FLIGHT_INFORMATION ="UPDATE flightinformation SET (?,?,?,?,?,?,?,?,?,?,?,?)  where flightno=?";
	
	public static final String VIEW_OVER_ALL_OCCUPANCY ="SELECT flightno,airline,(FirstSeats+BussSeats)AS occupancy FROM flightinformation WHERE dep_city=?,arr_city=?";
	
	public static final String VIEW_PERIOD_OCCUPANCY ="SELECT (FirstSeats+BussSeats)AS occupancy FROM flightinformation WHERE flightno=? BETWEEN dep_date=? AND dep_date=?";
	
}
