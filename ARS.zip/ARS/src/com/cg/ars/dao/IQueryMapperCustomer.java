package com.cg.ars.dao;

public interface IQueryMapperCustomer {

	public static final String VIEW_FLIGHTS ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation WHERE src_city=? AND dest_city=?";
	
	public static final String VIEW_RESERVATION ="SELECT booking_id, cust_email, no_of_passengers, class_type, total_fare, seat_number, CreditCard_info, src_city, dest_city FROM bookinginformation where booking_id=?";
	
	public static final String MAKE_RESERVATION ="INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?)";
	
	public static final String CANCEL_RESERVATION ="DELETE FROM bookinginformation WHERE booking_id=?";
	
	public static final String UPDATE_RESERVATION ="UPDATE bookinginformation SET no_of_passengers=?,class_type=?  where booking_id=?";
	
	
	
	
	
	
/*public static final String VIEW_FLIGHTS ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation";
	
	public static final String VIEW_RESERVATION ="SELECT booking_id, cust_email, no_of_passengers, class_type, total_fare, seat_number, CreditCard_info, src_city, dest_city FROM bookinginformation where booking_id=?";
	
	public static final String MAKE_RESERVATION ="INSERT INTO bookinginformation VALUES(booking_id, cust_email, no_of_passengers, class_type, total_fare, seat_number, CreditCard_info, src_city, dest_city)";
	
	public static final String CANCEL_RESERVATION ="DELETE FROM bookinginformation WHERE booking_id=?";
	
	public static final String UPDATE_RESERVATION ="UPDATE bookinginformation SET no_of_passengers=?,class_type=?  where booking_id=?";*/
	
	
	
	
	
	
	
	
}
