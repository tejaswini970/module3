package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO {			
	
	
	@Override
	public List<FlightInformationBean> viewFlights(String source,
			String destination) throws ARSException {
		
		List<FlightInformationBean>flightList=new ArrayList<FlightInformationBean>();
		
		try(Connection  conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_FLIGHTS);
				) {
			
			preparedStatement.setString(1,source);
			preparedStatement.setString(2,destination);
			ResultSet resultset = preparedStatement.executeQuery();
		
			while (resultset.next()){
				FlightInformationBean flightInformation=new FlightInformationBean();
				flightInformation.setFlightNumber(resultset.getString("flightno"));
				flightInformation.setAirline(resultset.getString("airline"));
				flightInformation.setDepartureCity(resultset.getString("dep_city"));
				flightInformation.setArrivalCity(resultset.getString("arr_city"));
				flightInformation.setDepartureDate(resultset.getDate("dep_date").toLocalDate());
				flightInformation.setArrivalDate(resultset.getDate("arr_date").toLocalDate());
				flightInformation.setDepartureTime(resultset.getString("dep_time"));
				flightInformation.setArrivalTime(resultset.getString("arr_time"));
				flightInformation.setFirstClassSeats(resultset.getInt("FirstSeats"));
				flightInformation.setFirstClassSeatFare(resultset.getDouble("FirstSeatFare"));
				flightInformation.setBussinessClassSeats(resultset.getInt("BussSeats"));
				flightInformation.setBussinessClassSeatsFare(resultset.getDouble("BussSeatsFare"));
				
				flightList.add(flightInformation);


			}
			
			if(flightList.size()==0){
				throw new ARSException("No flights found.");
			}			

			
		} catch (Exception e) {
			throw new ARSException(e.getMessage());
		}

		return flightList;
		
	}

	@Override
	public BookingInformationBean makeReservation(String flightNumber,
			String customerEmail, int numberOfPassengers, String classType,
			String creditCardInformation) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.MAKE_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

	@Override
	public BookingInformationBean viewReservation(String bookingId)
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

	@Override
	public boolean cancelReservation(String bookingId) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.CANCEL_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return false;
			
	}

	@Override
	public BookingInformationBean updateReservation(String bookingId,
			String classType, String numberOfPassengers) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.UPDATE_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

}
