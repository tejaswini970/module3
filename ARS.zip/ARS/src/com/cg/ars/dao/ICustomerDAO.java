package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

public interface ICustomerDAO {
	
	public List<FlightInformationBean> viewFlights(String source,String destination)  throws ARSException;
	
	public BookingInformationBean makeReservation(String flightNumber,String customerEmail,int numberOfPassengers,String classType,String creditCardInformation) throws ARSException;
	
	public BookingInformationBean viewReservation(String bookingId)  throws ARSException;
	
	public boolean cancelReservation(String bookingId)  throws ARSException;
	
	public BookingInformationBean updateReservation(String bookingId,String classType,String numberOfPassengers)  throws ARSException;
	
}
