package com.cg.ars.pi;

/************************
 * change in this main class will be done at last
 * 
 * 
 * 
 * 
 ***********************/
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.ars.exception.ARSException;
import com.cg.ars.service.StaffServiceImpl;

public class ARSMain {
	
	private static Logger logger=Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		boolean isInProcess = true;
		
		byte choice = 0;
	
		
		
		
		
		StaffServiceImpl userService = new StaffServiceImpl();

	

		Scanner scan = new Scanner(System.in);
		while (isInProcess) {
			System.out.println("1.Login");
            System.out.println("2.Flight Information");
            System.out.println("3.Book a Flight");
            System.out.println("4.Cancel or Change Booking");
            System.out.println("5.Exit");
			choice = Byte.parseByte(scan.nextLine());
			
			switch (choice){
			case 1:
				
               
				
				
				
				try{
					
					user=userService.verifyUser(userName,password,role);
					if(user==null)
					{
						System.out.println("Invalid Credentials");
					}
					else
					{
						System.out.println("Welcome "+user);
					}
					
				}catch(ARSException e){
					logger.error(e.getMessage());
				}
			
			break;
			case 5:
				isInProcess=false;
				break;
			}
		}
		scan.close();
		
		}
		

}
