package com.cg.ars.pi;

import java.util.Scanner;

public class StaffMain {

	byte staff=0;
	String userName = null;
	String password = null;
	String role = null;

	Scanner scan = new Scanner(System.in);
	    System.out.println("select staff role");
		System.out.println("1.Admin Login");
		System.out.println("2.Executive Login");
		staff=Byte.parseByte(scan.nextLine());

		System.out.println("Enter User Name: ");
		userName= scan.nextLine();
		System.out.println("Enter Password: ");
		password= scan.nextLine();
		
}
