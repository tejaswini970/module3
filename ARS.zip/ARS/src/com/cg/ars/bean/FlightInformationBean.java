package com.cg.ars.bean;

import java.time.LocalDate;

public class FlightInformationBean {
	
	private String flightNumber;
	private String airline;
	private String departureCity;
	private String arrivalCity;
	private LocalDate departureDate;
	private LocalDate arrivalDate;
	private String departureTime;
	private String arrivalTime;
	private int firstClassSeats;
	private int bussinessClassSeats;
	private double firstClassSeatFare;
	private double bussinessClassSeatsFare;
	
	public FlightInformationBean() {
		super();
	}
	
	public FlightInformationBean(String flightNumber, String airline,
			String departureCity, String arrivalCity, LocalDate departureDate,
			LocalDate arrivalDate, String departureTime, String arrivalTime,
			int firstClassSeats, int bussinessClassSeats,
			double firstClassSeatFare, double bussinessClassSeatsFare) {
		super();
		this.flightNumber = flightNumber;
		this.airline = airline;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.firstClassSeats = firstClassSeats;
		this.bussinessClassSeats = bussinessClassSeats;
		this.firstClassSeatFare = firstClassSeatFare;
		this.bussinessClassSeatsFare = bussinessClassSeatsFare;
	}
	
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public LocalDate getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(LocalDate departureDate) {
		this.departureDate = departureDate;
	}
	public LocalDate getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(LocalDate arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public int getFirstClassSeats() {
		return firstClassSeats;
	}
	public void setFirstClassSeats(int firstClassSeats) {
		this.firstClassSeats = firstClassSeats;
	}
	public int getBussinessClassSeats() {
		return bussinessClassSeats;
	}
	public void setBussinessClassSeats(int bussinessClassSeats) {
		this.bussinessClassSeats = bussinessClassSeats;
	}
	public double getFirstClassSeatFare() {
		return firstClassSeatFare;
	}
	public void setFirstClassSeatFare(double firstClassSeatFare) {
		this.firstClassSeatFare = firstClassSeatFare;
	}
	public double getBussinessClassSeatsFare() {
		return bussinessClassSeatsFare;
	}
	public void setBussinessClassSeatsFare(double bussinessClassSeatsFare) {
		this.bussinessClassSeatsFare = bussinessClassSeatsFare;
	}
	
	@Override
	public String toString() {
		return "FlightInformationBean [flightNumber=" + flightNumber
				+ ", airline=" + airline + ", departureCity=" + departureCity
				+ ", arrivalCity=" + arrivalCity + ", departureDate="
				+ departureDate + ", arrivalDate=" + arrivalDate
				+ ", departureTime=" + departureTime + ", arrivalTime="
				+ arrivalTime + ", firstClassSeats=" + firstClassSeats
				+ ", bussinessClassSeats=" + bussinessClassSeats
				+ ", firstClassSeatFare=" + firstClassSeatFare
				+ ", bussinessClassSeatsFare=" + bussinessClassSeatsFare + "]";
	}
	
	
}
