package com.cg.ars.bean;

public class BookingInformationBean {
	
	private String bookingId;
	private String customerEmail;
	private int numberOfPassengers;
	private String classType;
	private double totalFare;
	private String seatNumbers;
	private String creditCardInformation;
	private String sourceCity;
	private String destinationCity;
	
	public BookingInformationBean() {
		super();
	}

	public BookingInformationBean(String bookingId, String customerEmail,
			int numberOfPassengers, String classType, double totalFare,
			String seatNumbers, String creditCardInformation,
			String sourceCity, String destinationCity) {
		super();
		this.bookingId = bookingId;
		this.customerEmail = customerEmail;
		this.numberOfPassengers = numberOfPassengers;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNumbers = seatNumbers;
		this.creditCardInformation = creditCardInformation;
		this.sourceCity = sourceCity;
		this.destinationCity = destinationCity;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}

	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public String getSeatNumbers() {
		return seatNumbers;
	}

	public void setSeatNumbers(String seatNumbers) {
		this.seatNumbers = seatNumbers;
	}

	public String getCreditCardInformation() {
		return creditCardInformation;
	}

	public void setCreditCardInformation(String creditCardInformation) {
		this.creditCardInformation = creditCardInformation;
	}

	public String getSourceCity() {
		return sourceCity;
	}

	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}

	@Override
	public String toString() {
		return "BookingInformationBean [bookingId=" + bookingId
				+ ", customerEmail=" + customerEmail + ", numberOfPassengers="
				+ numberOfPassengers + ", classType=" + classType
				+ ", totalFare=" + totalFare + ", seatNumbers=" + seatNumbers
				+ ", creditCardInformation=" + creditCardInformation
				+ ", sourceCity=" + sourceCity + ", destinationCity="
				+ destinationCity + "]";
	}
	
	
}
