package com.cg.ars.service;

import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.dao.CustomerDAOImpl;
import com.cg.ars.dao.ICustomerDAO;
import com.cg.ars.exception.ARSException;

public class CustomerServiceImpl implements ICustomerService {
	
	ICustomerDAO customerDAO = new CustomerDAOImpl();
	
	@Override
	public List<FlightInformationBean> viewFlights(String source,
			String destination) throws ARSException {
		
		return customerDAO.viewFlights(source, destination);
	}

	@Override
	public BookingInformationBean makeReservation(String flightNumber,
			String customerEmail, int numberOfPassengers, String classType,
			String creditCardInformation) throws ARSException {

		return customerDAO.makeReservation(flightNumber, customerEmail, numberOfPassengers, classType, creditCardInformation);
	}

	@Override
	public BookingInformationBean viewReservation(String bookingId)
			throws ARSException {

		return customerDAO.viewReservation(bookingId);
	}

	@Override
	public boolean cancelReservation(String bookingId) throws ARSException {
	
		return customerDAO.cancelReservation(bookingId);
	}

	@Override
	public BookingInformationBean updateReservation(String bookingId,
			String classType, String numberOfPassengers) throws ARSException {

		return customerDAO.updateReservation(bookingId, classType, numberOfPassengers);
	}

}
