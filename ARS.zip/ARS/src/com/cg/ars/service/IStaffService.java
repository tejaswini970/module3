package com.cg.ars.service;


import java.time.LocalDate;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

public interface IStaffService {
	
	public boolean verifyUser(String userName,String password,String role) throws ARSException;
	
	public List<FlightInformationBean> viewFlightInformation()  throws ARSException;
	
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)  throws ARSException;
	
	public boolean updateFlightInformation(FlightInformationBean flightInfoBean) throws ARSException;
	
	public List<FlightInformationBean> viewOverAllOccupancy(String sourceCity,String destinationCity) throws ARSException;
	
	public int viewPeriodOccupancy(String flightNumber,LocalDate fromDate,LocalDate toDate) throws ARSException;
	
	
}
