package com.capgemini.eBill.service;

import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.exception.BillException;

public interface IEBillService 
{
	public int addBill(BillDTO bill) throws BillException;
	
	public Consumer getConsumerDetails(int consumerNumber) throws BillException;
}
