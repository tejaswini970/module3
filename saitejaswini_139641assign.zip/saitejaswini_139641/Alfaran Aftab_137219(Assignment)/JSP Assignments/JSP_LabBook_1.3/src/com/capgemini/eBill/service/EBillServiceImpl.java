package com.capgemini.eBill.service;

import com.capgemini.eBill.DAO.EBillDAOImpl;
import com.capgemini.eBill.DAO.IEBillDAO;
import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.exception.BillException;

public class EBillServiceImpl implements IEBillService
{

	IEBillDAO billDAO;
	
	public EBillServiceImpl()
	{
		billDAO = new EBillDAOImpl();
	}
	
	@Override
	public int addBill(BillDTO bill) throws BillException {
		return billDAO.addBill(bill);
	}

	@Override
	public Consumer getConsumerDetails(int consumerNumber) throws BillException {
		return billDAO.getConsumerDetails(consumerNumber);
	}

}
