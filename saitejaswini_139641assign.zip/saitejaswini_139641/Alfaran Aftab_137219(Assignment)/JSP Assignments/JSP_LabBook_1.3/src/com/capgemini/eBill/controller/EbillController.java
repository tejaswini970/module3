package com.capgemini.eBill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.exception.BillException;
import com.capgemini.eBill.service.EBillServiceImpl;
import com.capgemini.eBill.service.IEBillService;

@WebServlet("/EbillController")
public class EbillController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IEBillService service;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		super.init(config);
		
		service = new EBillServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String operation = request.getParameter("userAction");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		
		if (operation != null && "calculate".equals(operation)) 
		{
			String consumerNumberStr = request.getParameter("consumerNumber");
			int consumerNumber = Integer.valueOf(consumerNumberStr);
			String lastReadingStr = request.getParameter("lastReading");
			double lastReading = Double.valueOf(lastReadingStr);
			String currentReadingStr = request.getParameter("currentReading");
			double currentReading = Double.valueOf(currentReadingStr);
			
			Consumer consumer = null;
			try 
			{
				consumer = service.getConsumerDetails(consumerNumber);
				
			} 
			catch (BillException e) 
			{
				getServletContext().setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			
			BillDTO bill = new BillDTO();
			
			//bill.setBillNumber(billNumber);
			double fixedCharge = 100;
			double unitConsumed = 0;
			unitConsumed = currentReading - lastReading;
			double netAmount = 0;
			netAmount = (unitConsumed * 1.15) + fixedCharge;
			
			bill.setConsumerNumber(consumerNumber);
			bill.setCurrentReading(currentReading);
			bill.setUnitConsumed(unitConsumed);
			bill.setNetAmount(netAmount);
			bill.setDate(java.sql.Date.valueOf(LocalDate.now()));
			
			try 
			{
				int records = service.addBill(bill);
				
			}
			catch(BillException e)
			{
				getServletContext().setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			if(consumer != null)
			{
			getServletContext().setAttribute("consumer", consumer);
			getServletContext().setAttribute("bill", bill);
			view = request.getRequestDispatcher("Bill_Info.jsp");
			view.forward(request, response);
			}
			else
			{
				response.sendRedirect("Error.jsp");
			}
			
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
