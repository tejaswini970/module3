package com.capgemini.eBill.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.Util.DBUtil;
import com.capgemini.eBill.exception.BillException;


public class EBillDAOImpl implements IEBillDAO
{	
	@Override
	public int addBill(BillDTO bill) throws BillException 
	{
		Connection con = DBUtil.obtainConnection();
		String sql = "INSERT INTO billdetails VALUES(?,?,?,?,?,?)";

		int billNumber = 0;
		
		try
		{
			billNumber = getConsumerId();
			
			bill.setBillNumber(billNumber);
			
			PreparedStatement pst = con.prepareStatement(sql);
		
			pst.setInt(1, bill.getBillNumber());
			pst.setInt(2, bill.getConsumerNumber());
			pst.setDouble(3, bill.getCurrentReading());
			pst.setDouble(4, bill.getUnitConsumed());
			pst.setDouble(5, bill.getNetAmount());
			pst.setDate(6, new java.sql.Date(bill.getDate().getTime()));
			
			pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new BillException("Cannot add bill details. Reason is "+e.getMessage());
		}
		
		return billNumber;
	}
	
	public int getConsumerId() throws BillException
	{
		Connection con = DBUtil.obtainConnection();
		String sql = "SELECT seq_bill_num.nextVal FROM DUAL";
		
		int billNumber = 0;
		try 
		{
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery(sql);
			
			while(rs.next())
			{
				billNumber = rs.getInt(1);
			}
			
		} catch (Exception e) 
		{
			throw new BillException("Cannot generate bill number. Reason is "+e.getMessage());
		}
		return billNumber;
		
	}

	@Override
	public Consumer getConsumerDetails(int consumerNumber) throws BillException 
	{
		Connection con = DBUtil.obtainConnection();
		String sql = "SELECT * FROM Consumers where consumer_num = ?";
		
		Consumer consumer = null;
		
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, consumerNumber);
			
			ResultSet res = pst.executeQuery();
			
			if (res.next() == false)
				throw new BillException("No consumer found with number: " +consumerNumber);
			
			consumer = new Consumer();
			
			consumer.setConsumerNumber(res.getInt("consumer_num"));
			consumer.setConsumerName(res.getString("consumer_name"));
			consumer.setAddress(res.getString("address"));
		}
		catch(Exception e)
		{
			throw new BillException("Cannot view consumer. Reason is "+e.getMessage());
		}
		
		return consumer;
		
	}

	@Override
	public ArrayList<Consumer> viewConsumer() throws BillException 
	{
		ArrayList<Consumer> consumers = null;
		Connection con = DBUtil.obtainConnection();
		String sql = "SELECT * FROM Consumers";
		
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();
			
			consumers = new ArrayList<Consumer>();
			while(res.next())
			{
			
				Consumer consumer = new Consumer();
				
				consumer.setConsumerNumber(res.getInt("consumer_num"));
				consumer.setConsumerName(res.getString("consumer_name"));
				consumer.setAddress(res.getString("address"));
				
				consumers.add(consumer);
			}
			if (consumers.isEmpty())
				throw new BillException("No Consumer Details To Display.");
		}
		catch(Exception e)
		{
			throw new BillException("Cannot show the consumers");
		}
		return consumers;
	}

	@Override
	public ArrayList<BillDTO> viewBill(int consumerNumber) throws BillException
	{
		ArrayList<BillDTO> bills = null;
		Connection con = DBUtil.obtainConnection();
		String sql = "SELECT * FROM billdetails where consumer_num=?";
		
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, consumerNumber);
			
			ResultSet res = pst.executeQuery();
			bills = new ArrayList<BillDTO>();
			while(res.next())
			{
			
				BillDTO bill = new BillDTO();
				
				bill.setConsumerNumber(res.getInt("consumer_num"));
				bill.setBillNumber(res.getInt("bill_num"));
				bill.setDate(res.getDate("bill_date"));
				bill.setCurrentReading(res.getDouble("cur_reading"));
				bill.setUnitConsumed(res.getDouble("unitConsumed"));
				bill.setNetAmount(res.getDouble("netAmount"));

				bills.add(bill);
			}
			if (bills.isEmpty())
				throw new BillException("No bill Details To Display.");
		}
		catch(Exception e)
		{
			throw new BillException("Cannot show the bills");
		}
		return bills;
	}
}
