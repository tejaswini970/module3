CREATE TABLE Consumers( consumer_num NUMBER(6) PRIMARY KEY, consumer_name VARCHAR2(20) NOT NULL, address VARCHAR2(30) );

INSERT INTO Consumers VALUES(100001,'Sumeet','Shivaji Nagar, Pune'); 
INSERT INTO Consumers VALUES(100002,'Meenal','M G Colony Panvel, Mumbai'); 
INSERT INTO Consumers VALUES(100003,'Neeraj','Whitefield, Bangalore'); 
insert INTO Consumers VALUES(100004,'Arul','Karapakkam, Chennai');

 