package com.capgemini.useradd.DAO;

import java.util.ArrayList;

import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;

public interface IRegisterDAO 
{
	public int addUser(UserDTO user) throws UserException;
	
	public ArrayList<UserDTO> showUser() throws UserException;
}
