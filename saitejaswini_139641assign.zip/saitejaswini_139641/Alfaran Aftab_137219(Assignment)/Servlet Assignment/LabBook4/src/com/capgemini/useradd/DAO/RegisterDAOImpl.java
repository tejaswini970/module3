package com.capgemini.useradd.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;
import com.capgemini.useradd.util.DBUtil;

public class RegisterDAOImpl implements IRegisterDAO 
{

	@Override
	public int addUser(UserDTO user) throws UserException 
	{
		Connection con = DBUtil.obtainConnection();
		String sql = "INSERT INTO Users values(?,?,?,?,?,?)";
		
		int recordInserted = 0; 
		
		try
		{	
			
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,user.getFirstName());
			pst.setString(2, user.getLastName());
			pst.setString(3, user.getPassword());
			pst.setString(4, user.getGender());
			pst.setString(5, user.getSkillSet());
			pst.setString(6, user.getCity());
			
			recordInserted = pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			throw new UserException("Error while inserting. Reason is "+e.getMessage());
		}
		
		return recordInserted;
	}

	@Override
	public ArrayList<UserDTO> showUser() throws UserException 
	{
		Connection con = DBUtil.obtainConnection();
		String sql = "SELECT firstname,lastname,gender,skillset,city FROM Users";
		
		ArrayList<UserDTO> users = new ArrayList<UserDTO>();
		
		try 
		{
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next())
			{
				UserDTO user = new UserDTO();
				
				user.setFirstName(rs.getString("firstname"));
				user.setLastName(rs.getString("lastname"));
				user.setGender(rs.getString("gender"));
				user.setSkillSet(rs.getString("skillset"));
				user.setCity(rs.getString("city"));
				
				users.add(user);
			}
			
		} catch (SQLException e) 
		{
			throw new UserException("Cannot view details.Reason is "+e.getMessage());
		}
		
		return users;
	}

}
