package com.cg.filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

/**
 * Servlet Filter implementation class AuthFilter
 */
@WebFilter(filterName = "AuthFilter", urlPatterns = { "/WelcomeServlet" }, initParams = {
		@WebInitParam(name = "username", value = "123"),
		@WebInitParam(name = "password", value = "123") })
public class AuthFilter implements Filter {

	String username, password;

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		PrintWriter pw = response.getWriter();

		response.setContentType("text/html");

		String name = request.getParameter("username");
		String pwd = request.getParameter("password");

		if (name.equals(username) && pwd.equals(password)) {
			chain.doFilter(request, response);
		} else {
			pw.println(
				"<h1 style='color:red'>"
				+ "Invalid user credentials,"
				+ "<hr> cannot enter inside::: "
				+ "<br> Invalid user name given is::: " + name
			);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {

		username = fConfig.getInitParameter("username");
		password = fConfig.getInitParameter("password");

	}

}
