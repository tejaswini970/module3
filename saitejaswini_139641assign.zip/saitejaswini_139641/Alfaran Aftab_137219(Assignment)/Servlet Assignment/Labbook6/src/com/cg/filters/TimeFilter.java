package com.cg.filters;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class TimeFilter
 */
@WebFilter(filterName = "/TimeFilter", urlPatterns = { "/*" })
public class TimeFilter implements Filter {

    /**
     * Default constructor. 
     */
    public TimeFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		System.out.println("************************************* TimeFilter destroyed *************************");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		
		String ipAddress = request.getRemoteAddr();
		
		long startTime = System.currentTimeMillis();
		
		System.out.println("TimeFilter request Processing"
				+ "........IP " + ipAddress + ", Time " + LocalDate.now().toString());
		
		chain.doFilter(request, response);
		
		long endTime = System.currentTimeMillis();
		
		System.out.println("Total Request time: " + (endTime - startTime));
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("************************************* TimeFilter init *************************");
	}

}
