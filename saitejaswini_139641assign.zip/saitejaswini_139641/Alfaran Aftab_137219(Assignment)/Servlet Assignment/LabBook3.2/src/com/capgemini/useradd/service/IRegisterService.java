package com.capgemini.useradd.service;

import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;

public interface IRegisterService 
{
	public int addUser(UserDTO user) throws UserException;
}
