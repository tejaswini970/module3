package com.capgemini.useradd.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;
import com.capgemini.useradd.util.DBUtil;

public class RegisterDAOImpl implements IRegisterDAO 
{

	@Override
	public int addUser(UserDTO user) throws UserException 
	{
		Connection con = DBUtil.obtainConnection();
		String sql = "INSERT INTO RegisteredUsers values(?,?,?,?,?,?)";
		
		int recordInserted = 0; 
		
		try
		{	
			
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,user.getFirstName());
			pst.setString(2, user.getLastName());
			pst.setString(3, user.getPassword());
			pst.setString(4, user.getGender());
			pst.setString(5, user.getSkillSet());
			pst.setString(6, user.getCity());
			
			recordInserted = pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			throw new UserException("Error while inserting. Reason is "+e.getMessage());
		}
		
		return recordInserted;
	}

}
