package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ebill.dto.Bill;
import com.cg.ebill.exception.EbillException;
import com.cg.ebill.utility.DBConnection;

public class ConsumerDAOImpl implements ConsumerDAO {
	@Override
	public List<Bill> searchBill(int ID) throws EbillException {
		List<Bill> list=new ArrayList<>();
		System.out.println(ID);
		Connection connection=DBConnection.getConnection();
		try(Statement statement=connection.createStatement();){
			ResultSet resultSet=statement.executeQuery("select * from BillDetails where consumer_num = "+ID);
			while(resultSet.next()){	
			Bill obj=new Bill();
				obj.setBillNum(resultSet.getInt(1));
				obj.setConsumerNum(resultSet.getInt(2));
				obj.setCurrentReading(resultSet.getFloat(3));
				obj.setUnitConsumed(resultSet.getFloat(4));
				obj.setNetAmount(resultSet.getFloat(5));
				obj.setBillDate(resultSet.getDate(6).toLocalDate());
				list.add(obj);
			}
		} catch (SQLException e) {
		throw new EbillException("Error occured while fetching data..");
		}
		return list;
	}
	@Override
	public void insertBill(Bill bill) throws EbillException{
		System.out.println("In the function");
		Connection connection=DBConnection.getConnection();
		System.out.println("Connection Setted");
		String query="Insert into billdetails ( bill_num , consumer_num , cur_reading , unitConsumed , netAmount) values (seq_bill_num.nextVal , ? , ? , ? , ? ) ";
		System.out.println("Query setted");
		try(PreparedStatement statement=connection.prepareStatement(query);){
			System.out.println("In the try block");
			statement.setInt(1, bill.getConsumerNum());
			statement.setFloat(2, bill.getCurrentReading());
			statement.setFloat(3, bill.getUnitConsumed());
			statement.setFloat(4, bill.getNetAmount());
			System.out.println("Prepared statement done");
			int noOfRowsInserted=statement.executeUpdate();
			System.out.println("Rows inserted="+noOfRowsInserted);
			connection.commit();
			System.out.println("Connection Commited");
			if (noOfRowsInserted==0)
			{
				System.out.println("Could not insert record in the database");
			}
			
		} catch (SQLException e) {
			throw new EbillException("Could not Insert bill record");
		}
	}

}