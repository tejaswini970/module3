package com.capgemini.exception;

public class DVDException extends Exception {

	public DVDException() {
		// TODO Auto-generated constructor stub
	}

	public DVDException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DVDException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public DVDException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DVDException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
