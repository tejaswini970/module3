package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.dto.Customer;
import com.capgemini.dto.DVD;
import com.capgemini.exception.DVDException;
import com.capgemini.util.DBUtil;

public class DVDDAOImpl implements IDVDDAO {

	/*
	 * Emp Id			=		137672
	 * Employee Name	=		Vishal
	 * Description		=		Fetching DVD records from table. Storing in ArrayList and returning arraylist of type DVD
	 * Creation date	=		07-11-2017
	 */
	
	@Override
	public ArrayList<DVD> getAllDVD() throws DVDException 
	{
		ArrayList<DVD> dvdList = null;
		try (Connection connection = DBUtil.getConnection()) 
		{
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM DVD");
			dvdList = new ArrayList<>();
			while (resultSet.next())
			{
				DVD dvd = new DVD(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3),
						resultSet.getString(4), resultSet.getDouble(5));
				dvdList.add(dvd);
			}
			if (dvdList.isEmpty())
			{
				throw new Exception("Sorry no DVD is present in database");
			} 
		}
		catch (Exception e) 
		{
			throw new DVDException(e.getMessage());
		}
		return dvdList;
	}

	
	/*
	 * Emp Id			=		137672
	 * Employee Name	=		Vishal
	 * Description		=		Code to insert Customer record in table
	 * Creation date	=		07-11-2017
	 */
	
	@Override
	public void addCustomerDetails(Customer customer) throws DVDException 
	{
		try (Connection connection = DBUtil.getConnection()) 
		{
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO CustomerDvdDetails values(?,?,?,?,?)");
			preparedStatement.setString(1, customer.getName());
			preparedStatement.setInt(2, customer.getDvdId());
			preparedStatement.setDate(3, Date.valueOf(customer.getDvdIssueDate()));
			preparedStatement.setDate(4, Date.valueOf(customer.getDvdReturnDate()));
			preparedStatement.setDouble(5, customer.getDeposit());
			preparedStatement.execute();
		} 
		catch (Exception e)
		{
			throw new DVDException(e.getMessage());
		}
	}

	/*
	 * Emp Id			=		137672
	 * Employee Name	=		Vishal
	 * Description		=		Code to get Customer record from table
	 * Creation date	=		07-11-2017
	 */
	
	@Override
	public Customer getCustomerDetails(String UserName) throws DVDException 
	{
		Customer customer = null;
		try (Connection connection = DBUtil.getConnection()) 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CustomerDvdDetails WHERE name=?");
			preparedStatement.setString(1, UserName);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) 
			{
				customer = new Customer(resultSet.getString(1), resultSet.getInt(2), resultSet.getDate(3).toLocalDate(),
						resultSet.getDate(4).toLocalDate(), resultSet.getDouble(5));
			}
		} 
		catch (Exception e) 
		{
			throw new DVDException(e.getMessage());
		}
		return customer;
	}

}
