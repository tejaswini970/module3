package com.cg.modulescoremanagement.dto;

public class AssesmentScore {

	public AssesmentScore() 
	{
		
	}
	
	private int id;
	private String moduleName;
	private int mpt;
	private int mtt;
	private int ass_marks;
	private int total;
	private int grade;
	
	
	@Override
	public String toString() {
		return "AssesmentScore [id=" + id + ", moduleName=" + moduleName + ", mpt=" + mpt + ", mtt=" + mtt
				+ ", ass_marks=" + ass_marks + ", total=" + total + ", grade=" + grade + "]";
	}
	public AssesmentScore(String moduleName, int mpt, int mtt, int ass_marks, int total, int grade) {
		super();
		this.moduleName = moduleName;
		this.mpt = mpt;
		this.mtt = mtt;
		this.ass_marks = ass_marks;
		this.total = total;
		this.grade = grade;
	}
	public AssesmentScore(int id, String moduleName, int mpt, int mtt, int ass_marks, int total, int grade) {
		super();
		this.id = id;
		this.moduleName = moduleName;
		this.mpt = mpt;
		this.mtt = mtt;
		this.ass_marks = ass_marks;
		this.total = total;
		this.grade = grade;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getMpt() {
		return mpt;
	}
	public void setMpt(int mpt) {
		this.mpt = mpt;
	}
	public int getMtt() {
		return mtt;
	}
	public void setMtt(int mtt) {
		this.mtt = mtt;
	}
	public int getAss_marks() {
		return ass_marks;
	}
	public void setAss_marks(int ass_marks) {
		this.ass_marks = ass_marks;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
}
