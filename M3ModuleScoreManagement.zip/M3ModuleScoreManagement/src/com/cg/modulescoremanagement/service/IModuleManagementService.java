package com.cg.modulescoremanagement.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.modulescoremanagement.dto.AssesmentScore;
import com.cg.modulescoremanagement.dto.Trainees;
import com.cg.modulescoremanagement.exception.ModuleException;

public interface IModuleManagementService 
{
	
	public ArrayList<Trainees> getTrainee() throws ModuleException;
	public AssesmentScore addScore(AssesmentScore obj) throws ModuleException;
}
