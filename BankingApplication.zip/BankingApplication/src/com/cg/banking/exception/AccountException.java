package com.cg.banking.exception;

public class AccountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6836331880347274582L;
	public AccountException(String message)
	{
		super(message);
	}
}
