package com.cg.banking.dao;

import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.exception.AccountException;




public interface IAccountDAO {

	  
	List<BankingBean> getAccount(String customer_name) throws AccountException;
	
	float getBalance(String account_number) throws AccountException;
	boolean updateBalance(String account_number,float balance) throws AccountException;
	boolean insertTransaction(String account_number,float amount) throws AccountException;
}
