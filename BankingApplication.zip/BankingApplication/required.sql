create table account_details (account_number varchar2(20) primary key,customer_name varchar2(15),account_type varchar2(15), account_location varchar2(20),balance number(9,2));


create table transaction_details(transaction_id number(10) primary key, transaction_description varchar2(20), transaction_amount number(9,2),transaction_date date,account_number varchar2(20) references account_details(account_number));

insert into account_details values('002601988765','vikram Sharma','savings','powai',7656.00);

insert into account_details values('002601988871','vikram Sharma','current','ghatkopur',656.00);

insert into account_details values('002601988456','vishali S','savings','thane',70000.00);

insert into account_details values('002601988083','vishali S','current','aiori',25000.00);


insert into transaction_details values('1','ATM debit',1000,'04-12-2014','002601988765');

insert into transaction_details values('2','cheque deposit',5000,'08-24-2014','002601988765');

insert into transaction_details values('3','ATM debit',4000,'06-23-2015','002601988083');

insert into transaction_details values('4','cash deposit',4000,'08-11-2015','002601988083');


create sequence transaction_id_seq start with 5 increment by 1;

