package com.capgemini.lab32.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.lab32.bean.Registration;


@WebServlet("/RegistrationView")
public class RegistrationView extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Registration> studentList=(List<Registration>) request.getAttribute("studentList");
		PrintWriter out=response.getWriter();
		out.print("<table cellspacing='20' border=1>");
		out.print("<th>");
		
		
		out.print("<td>First Name</td>");
		out.print("<td>Last Name</td>");
		out.print("<td>Password</td>");
		out.print("<td>Gender</td>");
		out.print("<td>Skill Set</td>");
		out.print("<td>City</td>");
		
		out.print("</th>");
		for(Registration reg: studentList){
			out.print("<tr>");
			
			out.print("<td>" + reg.getFname() + "</td>");
			out.print("<td>" + reg.getLname() + "</td>");
			out.print("<td>" + reg.getPassword() + "</td>");
			out.print("<td>" + reg.getGender() + "</td>");
			out.print("<td>" + reg.getSkill() + "</td>");
			out.print("<td>" + reg.getCity() + "</td>");
			
			out.print("</tr>");
		}
		
		
		out.print("</table>");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
