package com.capgemini.lab32.service;

import java.util.List;

import com.capgemini.lab32.bean.Registration;

public interface RegistrationServiceIntf {

	public abstract void insertStudent(Registration reg) throws Exception;
	
	public abstract List<Registration> getStudent() throws Exception;

}