package com.capgemini.lab32.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBConnection {
	 private static Connection connection=null;
	 
		 public static Connection getConnection() throws Exception {
			InitialContext context;
			try{				
				if(connection==null){
					context=new InitialContext();
					DataSource datasource=(DataSource)context.lookup("java:/OracleDS");
					connection=datasource.getConnection();
					System.out.println(connection);
					System.out.println("connection successful");
					
				}
			}catch(SQLException e){
					throw new Exception("connection to databse failed,SQL EXCEPTION");
			} catch (NamingException e) {
				throw new Exception ("connection to databse failed,NAMING EXCEPTION");
			}
			return connection;
		}
}
