package com.capgemini.lab32.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.lab32.bean.Registration;
import com.capgemini.lab32.service.RegistrationServiceImpl;
import com.capgemini.lab32.service.RegistrationServiceIntf;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RegistrationServiceIntf service;
 
	public void init(ServletConfig config) throws ServletException {
		service=new RegistrationServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String msg="";
		Registration reg=new Registration();
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		String[] skill=request.getParameterValues("skill");
		String city=request.getParameter("city");
		
		
		reg.setFname(fname);
		reg.setLname(lname);
		reg.setPassword(password);
		reg.setGender(gender);
		String strSkill="";
		for(int i=0;i<skill.length;i++){
			strSkill= skill[i] + " " + strSkill;
		}		
		reg.setSkill(strSkill);
		reg.setCity(city);
		try {
			service.insertStudent(reg);			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}		
		
		try {
			List<Registration> List=service.getStudent();
			request.setAttribute("studentList",List);
			RequestDispatcher dispatcher=request.getRequestDispatcher("RegistrationView");
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
