package com.capgemini.lab32.service;

import java.util.List;

import com.capgemini.lab32.bean.Registration;
import com.capgemini.lab32.dao.RegistrationDAOImpl;
import com.capgemini.lab32.dao.RegistrationIntf;

public class RegistrationServiceImpl implements RegistrationServiceIntf {
	
	RegistrationIntf dao=new RegistrationDAOImpl();
	
	@Override
	public void insertStudent(Registration reg) throws Exception{
		dao.insertDetails(reg);
	}
	public List<Registration> getStudent() throws Exception{
		return dao.getStudent();
	}
}
