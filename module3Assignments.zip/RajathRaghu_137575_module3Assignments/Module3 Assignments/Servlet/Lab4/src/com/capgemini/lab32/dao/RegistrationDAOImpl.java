package com.capgemini.lab32.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.lab32.bean.Registration;
import com.capgemini.lab32.utility.DBConnection;

public class RegistrationDAOImpl implements RegistrationIntf {

	
	@Override
	public void insertDetails(Registration reg) throws Exception{
		Connection connection=DBConnection.getConnection();
		String query="Insert into RegisteredUsers values(?,?,?,?,?,?)";
		
		try(PreparedStatement statement=connection.prepareStatement(query);){
			statement.setString(1,reg.getFname());
			statement.setString(2,reg.getLname());
			statement.setString(3,reg.getPassword());
			statement.setString(4,reg.getGender());
			statement.setString(5,reg.getSkill());
			statement.setString(6,reg.getCity());
			
		
			
			int noOfRowsInserted=statement.executeUpdate();
			
			if(noOfRowsInserted !=1){
				throw new Exception("Insertion statement Failed ");		
			}
		}catch(SQLException e){
			
			throw new Exception("SQL exception" );
		}
	}
	@Override
	public List<Registration> getStudent() throws Exception{
		
		
		List<Registration> list=new ArrayList<Registration>();
		String query="Select * from RegisteredUsers";
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				ResultSet resultset=(statement).executeQuery(query);){

			while(resultset.next()){
				Registration reg=new Registration();
				reg.setFname(resultset.getString(1));
				reg.setLname(resultset.getString(2));
				reg.setPassword(resultset.getString(3));
				reg.setGender(resultset.getString(4));
				reg.setSkill(resultset.getString(5));
				reg.setCity(resultset.getString(6));
				
				list.add(reg);
				
			}
		}catch(SQLException e){
			
			throw new Exception("Could not retrive records from the db");
		}
		return list;
	}
}
