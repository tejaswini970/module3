package com.capgemini.lab32.dao;

import java.util.List;

import com.capgemini.lab32.bean.Registration;

public interface RegistrationIntf {

	public abstract void insertDetails(Registration reg) throws Exception;
	public abstract List<Registration> getStudent() throws Exception;
}