package com.capgemini.ebill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.demo.utility.DBConnection;
import com.capgemini.ebill.bean.Consumer;
import com.capgemini.ebill.bean.Ebill;
import com.capgemini.lab22.Exception.EbillException;
import com.sun.org.apache.regexp.internal.recompile;

public class EbillDaoImpl {
	
	
	public void insertDetails(Ebill ebill) throws Exception {
		Connection connection = DBConnection.getConnection();
		String query = "Insert into BILLDETAILS values(SEQ_BILL_NUM.nextVal,?,?,?,?,?)";

		try (PreparedStatement statement = connection.prepareStatement(query);) {
			System.out.println(ebill.getConsumerNumber());
			statement.setInt(1, ebill.getConsumerNumber());
			statement.setDouble(2, ebill.getCurReading());
			statement.setDouble(3, ebill.getUnitConsumed());
			statement.setDouble(4, ebill.getNetAmount());
			statement.setDate(5, Date.valueOf(ebill.getBillDate()));

			int noOfRowsInserted = statement.executeUpdate();
			if (noOfRowsInserted != 1) {
				throw new Exception("Insertion Failed in if block ");
			}
		} catch (SQLException e) {

			throw new Exception("Insertion Failed for ");
		}
	}
	
	public List<Consumer> SearchConsumer(int cNum) throws EbillException{
		
		Connection connection=DBConnection.getConnection();
		List<Consumer> conlist=new ArrayList<Consumer>();
		String query="select * from Consumers where consumer_num = " + cNum;	
		try(
			Statement statement=connection.createStatement();
			ResultSet resultset=statement.executeQuery(query);){
			while(resultset.next()){
				Consumer consumer=new Consumer();
				consumer.setConsumerNumber(resultset.getInt(1));
				consumer.setConsumerName(resultset.getString(2));
				consumer.setAddress(resultset.getString(3));
		
				conlist.add(consumer);
			}
			if(conlist.isEmpty()){
				throw new EbillException("Consumer Id Does Not Match With DB");
			}
		}catch (SQLException e) {
			
			throw new EbillException("Consumer Id Does Not Match With DB");
		}
		return conlist;			
	}
}

