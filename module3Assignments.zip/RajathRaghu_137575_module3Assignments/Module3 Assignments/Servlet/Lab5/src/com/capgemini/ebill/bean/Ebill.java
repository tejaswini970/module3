package com.capgemini.ebill.bean;

import java.time.LocalDate;

public class Ebill {
	private int billNum;
	private int consumerNumber;
	private double curReading;
	private double unitConsumed;
	private double netAmount;
	private LocalDate billDate;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getConsumerNumber() {
		return consumerNumber;
	}
	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}
	public double getCurReading() {
		return curReading;
	}
	public void setCurReading(double curReading) {
		this.curReading = curReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}

}
