package com.capgemini.ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.ebill.bean.Consumer;
import com.capgemini.ebill.bean.Ebill;
import com.capgemini.ebill.dao.EbillDaoImpl;


@WebServlet("*.mvc")
public class EBillServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private final int fixedCharge=100;
	private int cnum;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getServletPath();
		
		switch(action){
		case "/EBillServlet.mvc":
		
			Ebill ebill=new Ebill();
			
				PrintWriter out=response.getWriter();
				cnum=Integer.parseInt(request.getParameter("cNum"));
				int lmeter=Integer.parseInt(request.getParameter("lMeter"));
				int cmeter=Integer.parseInt(request.getParameter("cMeter"));
				int unitConsumed=cmeter-lmeter;
				double netAmount=(unitConsumed * 1.15) + fixedCharge; 
				
				
				
				ebill.setConsumerNumber(cnum);
				ebill.setCurReading(cmeter);
				ebill.setBillDate(LocalDate.now());
				ebill.setNetAmount(netAmount);
				ebill.setUnitConsumed(unitConsumed);
				
				
				EbillDaoImpl service=new EbillDaoImpl();
				
				
			try {
				service.insertDetails(ebill);
				List<Consumer> consumerList =service.SearchConsumer(cnum);
				request.getSession().setAttribute("list", consumerList);
				response.sendRedirect("ShowDetails.mvc");
			} catch (Exception e) {
				
			}
			break;
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
