/*
CREATE TABLE Student(
StudentNo number CONSTRAINT pk_Sno1 PRIMARY KEY,
studentName varchar(20),phone number, 
address varchar(20), deptno number, 
 admissionDate date,
CONSTRAINT fk_Dno1 FOREIGN KEY(Deptno) REFERENCES Department1(Deptno)
	);
*/

package com.capgemini.demo.utility;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.lab22.Exception.EbillException;

public class DBConnection {
	 private static Connection connection=null;
	
	public static Connection getConnection() throws EbillException{
			/*String url="jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
			String username="lab2etrg19";
			String password="lab2eoracle";*/
			InitialContext context;
			try{				
					context=new InitialContext();
					DataSource datasource=(DataSource)context.lookup("java:/OracleDS");
					connection=datasource.getConnection();
					System.out.println(connection);
					System.out.println("connection successful");
					
			}catch(SQLException e){
					throw new EbillException ("connection to databse failed,SQL EXCEPTION");
			} catch (NamingException e) {
				throw new EbillException ("connection to databse failed,NAMING EXCEPTION");
			}
			return connection;
		}
	}


