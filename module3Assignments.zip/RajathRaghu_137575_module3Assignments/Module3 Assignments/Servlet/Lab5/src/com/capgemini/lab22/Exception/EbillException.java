package com.capgemini.lab22.Exception;

public class EbillException extends Exception {
	
	public EbillException(String str){
		super(str);
	}
}
