package com.capg.java.service;

import com.capg.java.dao.RegisterDAOImpl;
import com.capg.java.dto.User;



public class RegisterServiceImpl 
{


public int op;
	
	public RegisterServiceImpl(User user)
	{
		
		new RegisterDAOImpl(user);
		
	}
	public RegisterServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public void getRedirect(int op)
	{
		this.op=op;
		
		
	}
}
