package com.capg.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capg.java.dto.User;
import com.capg.java.service.RegisterServiceImpl;

public class RegisterDAOImpl
{

	public RegisterDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	int rs;
	InitialContext inc;
	public RegisterDAOImpl(User udto){
	try {
		inc=new InitialContext();
		DataSource ds=(DataSource)inc.lookup("java:jboss/datasources/ExampleDS");
		Connection con=ds.getConnection();
		PreparedStatement ps=con.prepareStatement("Insert into RegisteredUsers values (?,?,?,?,?,?)");
		
		ps.setString(1, udto.getfName());
		ps.setString(2, udto.getlName());
		ps.setString(3, udto.getpWord());
		ps.setString(4, udto.getGender());
		ps.setString(5, udto.getSkillSet());
		ps.setString(6, udto.getCity());
		
		rs=ps.executeUpdate();
		if(rs==1)
		{
			new RegisterServiceImpl().getRedirect(rs);
		}
		} catch (NamingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
