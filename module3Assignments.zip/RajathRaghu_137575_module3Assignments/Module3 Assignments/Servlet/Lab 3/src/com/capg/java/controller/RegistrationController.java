package com.capg.java.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.java.dto.User;
import com.capg.java.service.RegisterServiceImpl;



@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public RegistrationController() 
    {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String skills="";
		String skillSet[];
		User user=new User();
		user.setfName(request.getParameter("fName"));
		user.setlName(request.getParameter("lName"));
		user.setpWord(request.getParameter("pWord"));
		user.setGender(request.getParameter("gender"));
		
		skillSet=request.getParameterValues("skill");
		for(int i=0;i<skillSet.length;i++)
			skills+=skillSet[i];
		user.setSkillSet(skills);
		user.setCity(request.getParameter("city"));
		RegisterServiceImpl rsi=new RegisterServiceImpl(user);
		if(rsi.op==0)
			response.sendRedirect("Welcome.html");
		else
			response.sendRedirect("Error.html");
	}

}
