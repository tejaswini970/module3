package com.capg.java;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name="admin";
		String pwd="admin";
		
		if(name.equalsIgnoreCase(request.getParameter("uName"))&&pwd.equalsIgnoreCase(request.getParameter("pWord")))
		{
			RequestDispatcher rd=request.getRequestDispatcher("Success.html");
			rd.forward(request, response);
		}
		else if(!name.equalsIgnoreCase(request.getParameter("uName"))||!pwd.equalsIgnoreCase(request.getParameter("pWord")))
		{
			RequestDispatcher rd=request.getRequestDispatcher("Failure.html");
			rd.forward(request, response);
		}

}
}