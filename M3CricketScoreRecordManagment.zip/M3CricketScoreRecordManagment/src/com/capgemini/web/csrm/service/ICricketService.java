package com.capgemini.web.csrm.service;

import java.util.List;

import com.capgemini.web.csrm.dto.PlayerBean;
import com.capgemini.web.csrm.exception.CricketScoreException;

public interface ICricketService {
	/**
	 * @param playerBean
	 * @return
	 * @throws CricketScoreException
	 */
	public int addPlayer(PlayerBean playerBean) throws CricketScoreException;
	/**
	 * @return
	 * @throws CricketScoreException
	 */
	public List<PlayerBean> viewAllPlayers() throws CricketScoreException;
}
